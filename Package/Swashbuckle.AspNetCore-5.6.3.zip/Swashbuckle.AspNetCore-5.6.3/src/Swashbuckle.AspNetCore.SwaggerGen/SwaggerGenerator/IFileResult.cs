﻿namespace Swashbuckle.AspNetCore.SwaggerGen
{
    internal interface IFileResult
    {
    }
}