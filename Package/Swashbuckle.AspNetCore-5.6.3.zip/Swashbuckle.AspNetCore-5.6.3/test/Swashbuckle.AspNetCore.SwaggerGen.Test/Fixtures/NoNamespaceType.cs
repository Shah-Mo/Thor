﻿public class NoNamespaceType
{
}