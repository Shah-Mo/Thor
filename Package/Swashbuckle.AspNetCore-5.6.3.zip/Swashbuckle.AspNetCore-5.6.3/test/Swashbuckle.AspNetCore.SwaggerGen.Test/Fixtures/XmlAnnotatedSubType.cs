﻿namespace Swashbuckle.AspNetCore.SwaggerGen.Test
{
    /// <summary>
    /// Summary for XmlAnnotatedSubType
    /// </summary>
    public class XmlAnnotatedSubType : XmlAnnotatedType
    {
    }
}