﻿namespace Swashbuckle.AspNetCore.TestSupport
{
    public class ComplexType2
    {
        public int IntProperty { get; set; }

        public string StringProperty { get; set; }

        public int? NullableIntProperty { get; set; }
    }
}
