﻿namespace Swashbuckle.AspNetCore.TestSupport
{
    public class SelfReferencingType
    {
        public SelfReferencingType Another { get; set; }
    }
}