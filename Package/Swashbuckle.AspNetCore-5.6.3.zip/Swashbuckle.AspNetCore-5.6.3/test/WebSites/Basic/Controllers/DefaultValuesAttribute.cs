﻿using System;

namespace Basic.Controllers
{
    internal class DefaultValuesAttribute : Attribute
    {
    }
}